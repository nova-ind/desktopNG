declare class SchemaNotFound extends Error {
    constructor(uri: string);
}
export = SchemaNotFound;
//# sourceMappingURL=schema-not-found-error.d.ts.map