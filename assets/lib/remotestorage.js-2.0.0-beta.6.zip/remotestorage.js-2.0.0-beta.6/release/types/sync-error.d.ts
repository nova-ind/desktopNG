declare class SyncError extends Error {
    originalError: Error;
    constructor(originalError: string | Error);
}
export = SyncError;
//# sourceMappingURL=sync-error.d.ts.map