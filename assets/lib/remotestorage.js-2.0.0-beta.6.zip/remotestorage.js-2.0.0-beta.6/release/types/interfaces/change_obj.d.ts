export declare type ChangeObj = {
    [key: string]: any;
};
//# sourceMappingURL=change_obj.d.ts.map