/// <reference types="tv4" />
export declare type JsonSchemas = {
    [key: string]: tv4.JsonSchema;
};
//# sourceMappingURL=json_schema.d.ts.map