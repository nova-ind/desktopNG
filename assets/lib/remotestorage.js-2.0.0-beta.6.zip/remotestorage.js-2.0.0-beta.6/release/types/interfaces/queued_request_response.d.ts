export declare type QueuedRequestResponse = {
    statusCode: number;
    body?: object;
    contentType?: string;
    revision?: string;
};
//# sourceMappingURL=queued_request_response.d.ts.map