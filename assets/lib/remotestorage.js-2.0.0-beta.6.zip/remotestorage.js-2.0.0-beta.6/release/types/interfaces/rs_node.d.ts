export declare type RSNode = {
    [key: string]: any;
};
export declare type RSNodes = {
    [key: string]: RSNode;
};
export declare type ProcessNodes = {
    (nodePaths: string[], nodes: RSNodes): RSNodes;
};
//# sourceMappingURL=rs_node.d.ts.map