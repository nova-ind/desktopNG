export declare type StorageInfo = {
    href: string;
    storageApi: string;
    authURL: string;
    properties: object;
    userAddress?: string;
};
//# sourceMappingURL=storage_info.d.ts.map