export declare type EventHandler = (event?: unknown) => void;
//# sourceMappingURL=event_handling.d.ts.map