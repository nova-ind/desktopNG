export declare type RSEvent = {
    [key: string]: string;
};
//# sourceMappingURL=rs_event.d.ts.map