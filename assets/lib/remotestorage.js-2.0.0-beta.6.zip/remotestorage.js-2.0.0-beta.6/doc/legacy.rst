Legacy docs
===========

These documents have been converted from the old Markdown files in the repo's
``doc/`` folder, but have not yet been updated, rewritten, deleted, or
integrated into the new docs. In short: TO DO, PLZ HELP. ;)

.. toctree::
   :maxdepth: 2
   :glob:

   legacy/*
