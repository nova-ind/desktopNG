Libary internals
================

This section contains information about some of the internals and
concepts of the remoteStorage.js library.

.. toctree::
   :maxdepth: 2

   internals/discovery-bootstrap
   internals/caching
   internals/cache-data-format

