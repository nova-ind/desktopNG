__version__ = '2.0.0-beta.6'
