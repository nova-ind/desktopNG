export type RSEvent = {
  [key: string]: string;
};
