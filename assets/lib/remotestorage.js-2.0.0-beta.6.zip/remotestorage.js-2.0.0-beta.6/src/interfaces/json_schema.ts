export type JsonSchemas = { [key: string]: tv4.JsonSchema };
