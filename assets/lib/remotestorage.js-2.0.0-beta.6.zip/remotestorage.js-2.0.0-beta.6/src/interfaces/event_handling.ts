export type EventHandler = (event?: unknown) => void;
