// TODO make definition more specific if possible
export type ChangeObj = {
  [key: string]: any;
};
