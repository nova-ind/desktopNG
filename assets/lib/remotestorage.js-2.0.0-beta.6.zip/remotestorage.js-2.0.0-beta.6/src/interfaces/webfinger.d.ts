declare module "webfinger.js" {
  export default function WebFinger(config?: {[key: string]: any}): void;
}
