# remoteStorage.js Changelog

All releases can also be found and downloaded on the [releases page][1] on GitHub.

## 2.0.0 (January 2022)

### Breaking changes

* Remove Bower package support (#1231)
* Minimum sync interval is now 2000ms (#1260)

### Enhancements

* Convert source code to TypeScript (#1175, #1196, #1199, #1211, #1214, #1233, #1239, #1249)
* Update dependencies (#1206, #1226)
* Switch from Travis CI to GitHub Actions (#1223, #1224, #1225)
* Don't add trailing slash as only pathname to redirect_uri param (#1213)
* BaseClient#getObject: Throw error instead of string when JSON parsing fails (#1215)
* Improve documentation (#1219, #1227, #1241, #1242)
* Make ReadTheDocs work with current node.js/npm, TypeDoc, etc. (#1220, #1230)
* Don't include unnecessary files in npm package (#1232)
* Improve validation of custom sync interval settings (#1260)
* Allow to connect via URL (#1250)

### Bugfixes

* Fix WireClient initialization when localStorage settings data corrupted/missing (#1210)
* Handle Google Drive paths with special characters (#1181)
* Fix potentially wrong command in warning message (#1218)
* Don't list trashed files in GDrive folder listings (#1257)

## 1.2.3 (January 2020)

### Enhancements

* Update dependencies (#1172)

### Bugfixes

* Fix wrong comparison in Sync class (#1164)

## 1.2.2 (March 2019)

Many thanks to @iLiviu for contributing all fixes in this release!

### Bugfixes

* Fix retrieval of binary files from Dropbox and Google Drive (#1155)
* Fix BaseClient.remove not working correctly while offline (#1160)
* Fix detecting changes in subfolders for Dropbox (#1161)

## 1.2.1 (January 2019)

### Bugfixes

* Fix Dropbox and Google Drive adapters failing with Fetch API (#1152, by
  @iLiviu)

## 1.2.0 (December 2018)

### Enhancements

* Use Fetch API for Webfinger requests (with fallback to XHR) (#1142)

### Security

* Update dependency locking, ensure HTTPS URLs (#1144)
* Update dependencies (#1044, #1048)

## 1.1.0 (November 2018)

### Bugfixes

* Fix remote Dropbox changes not being synced (#1128)
* Fix error when using in WebWorker (#1126)
* Fix error when minified via Uglify.js/create-react-app (#1133)

### Enhancements

* Use Fetch API for HTTP requests (with fallback to XHR) (#1132)
* Document usage with Cordova apps (#1138)
* Update dependencies and build setup
* Source code refactoring

## 1.0.3 (March 2018)

### Bugfixes

* Fix missing If-Match headers on PUT requests (#1121)
* Fix sync errors after disconnect (#939, #1117)
* Use/update correct version number for documentation (#1115)

### Enhancements

* Update dependencies, build config (#1122)
* Documentation fixes and improvements

## 1.0.2 (November 2017)

### Bugfixes

* Fix Dropbox offline issues (#1102)

### Enhancements

* Refactorings and cleanups
* Documentation fixes and improvements

## 1.0.1 (November 2017)

### Bugfixes

* Fix Dropbox throwing an error on failed requests (#1096)

## 1.0.0 (November 2017)

### Breaking changes

* All builds, including AMD/CommonJS and no-cache, are now rolled into one UMD
  build. (#951)
* `RemoteStorage.defineModule` is no more, and both declaring modules and
  loading them in apps can now be done with a new, improved API. (#974)
* The connect widget is not part of the core library anymore, but has moved to
  a seperate add-on library (#862)
* Error events (e.g. unauthorized, sync error, etc.) are identified by name
  instead of type now (#984)
* Network request timeouts are configured via the `setRequestTimeout` method
  on the RemoteStorage instance instead of setting
  `RemoteStorage.WireClient.REQUEST_TIMEOUT` (#983).
* Deprecated method `equalObj` from `RemoteStorage.util` has been
  removed
* `setApiKeys` takes a config object as argument to allow to configure
  multiple backends at once (#1021)
* The sync events 'done' and 'req-done' are emitted by the `remoteStorage`
  instance instead of `remoteStorage.sync` as 'sync-done' and
  'sync-req-done (#1044)
* The network events 'wire-busy' and 'wire-done' are emitted by the
  `remoteStorage` instance instead of `remoteStorage.remote` (#1044)

### Enhancements

* Switch Dropbox adapter to use the Dropbox API v2 (#936)
* Store data in Google Drive under "remotestorage" base dir (#962)
* Use email address as user address when connected to Google Drive (#955)
* Emit `Unauthorized` error on 401 responses (#1018)
* Emit `Unauthorized` error with code "access_denied" when user denies
  access (#1018)
* Add `reconnect()` method to retrieve new authorization (e.g. after it
  expired) (#1018)
* `startSync()` returns the sync promise (#1036)
* Emit `ready`, `connected` and `not-connected` events when registering an
  handler after they happened originally. (#1066)
* Introduce ESLint, fix syntax and scope issues throughout the code (#1080)

### Bugfixes

* Fix sync errors after disconnect (#994)
* Fix discovery problems in Internet Explorer (#1018)
* Fix error when trying to delete last document in a directory (#993)
* Fix Dropbox files not being deleted when they had been created in the
  same session (#1042)
* Emit 'wire-busy' and 'wire-done' events when using Dropbox or Google
  Drive (#957)

## 0.14.0 (November 2016)

### Enhancements

* Add network-offline and network-online events (#952)
* Document `remoteStorage.startSync()` (#954)
* Improve README.md a bit

### Bugfixes

* Fix widget not showing errors (#948)
* Keep Dropbox client trying to sync when offline (#956)
* Fix widget offline mode for Dropbox and Google Drive (#959)

## 0.13.0 (September 2016)

### Enhancements

* Support Safari private browsing mode (#921)
* Remove Bluebird dependency from AMD build (#917)

### Bugfixes

* Don't send empty state parameter in authorize URI (#908)
* Fix authorization error when using remoteStorage in Cordova (#919)
* Fix disconnect / initialization issues (#930)
* Start sync automatically after calling `configure` (#885, #820)
* Fix IndexedDB error on disconnect (#874)
* Fix IndexedDB getting into inconsistent state (#882)
* Fix `getListing` behaviour when called with invalid path (#932)
* Fix unresolved promise when trying to retrieve non-existing file (#934)
* Fix 3rd party backend initilization on first app load (#941)
* Fix Dropbox adapter not hooking itself into sync on connect (#851)
* Don't send change event if neither body nor content-type changed (#764)
* Fix connecting account when localStorage is not available
* Fix AMD build (#945)

### Breaking Changes

* Use common base directory for all remoteStorage data in Dropbox (#796)

## 0.12.1 (October 2015)

* Use main repo for Bower (add bower.json, re-organize release dir, #901)
* Make sure to support draft-05 style WebFinger responses (#899)
* Update dependencies

## 0.12.0 (October 2015)

### New features

* Make it possible to directly connect a remote storage from a program by
  calling connect() with an extra token parameter
* Add support for remoteStorage authorization from within Cordova apps, using
  the in-app-browser Cordova plugin (contributed by Lewis Liu)

### Enhancements

* Update dependencies (notable: new output format for test suites)
* When offline, ignore maxAge (with log) instead of failing (#868)
* Refactor test invocation in Makefile, package.json and .travis.yml (#892)
* Improved validation of `Caching#set` function arguments (#889)

### Bugfixes

* Fix syntax errors in ES6 strict mode (#872)
* Reset IndexedDB database when opening fails (#882)

### Experimental features

* Change configuration keys for Dropbox and Google Drive
* Documentation updates for Dropbox and Google Drive

## 0.11.2 (February 2015)

### Bugfixes

* Fix usage of FileReader that doesn't support `addEventListener` (#836)
* Fix widget not being set to correct mode in some cases (e.g. offline) (#740)
* Don't use incompatible/buggy IndexedDB implementations (#841)
* Blob constructor not available in older browsers (#843)

## 0.11.1 (January 2015, Hacker Beach Edition)

### Bugfixes

* Fix single quotes in filenames not working correctly (#812)
* Fix broken AMD build (#816)
* Fix syntax error in minified build (#817)
* Fix console errors when using lib without widget (#829)

## 0.11.0 (October 2014)

### Bugfixes

* Do not set a timestamp in local changes (#756)
* Replace custom promise implementation with [Bluebird](https://github.com/petkaantonov/bluebird) (#770)
* Replace custom WebFinger lookup with [webfinger.js](https://github.com/silverbucket/webfinger.js) (#256)

### New features

* Reintroduce remoteStorage.utils as RemoteStorage.utils (#761)
* Add more `remoteStorage.utils` helper methods (`isDocument`, `equal`, `equalObj`, `md5sum`)
* Complete node support ([documentation](https://github.com/remotestorage/remotestorage.js/blob/master/doc/nodejs.md))
* Expose WebFinger link properties as remoteStorage.remote.properties (#772)

### Experimental features

* Improvements to the Dropbox backend. (#784)

## 0.10.2 (September 2014)

### Bugfixes

* Fix bug in displayWidget (#749)
* Report unhandled HTTP status codes as errors (#594)
* Pause between sync retries when offline (#740)
* Fix race condition in caching layer (#752)

## 0.10.1 (August 2014)

### Bugfixes

* Remove old webfinger URL and increase discovery timeout (#591)
* Set the charset for binary, but not for UTF-8 (#668)
* Fix coming back online (#725)
* Fix merging of mutual deletions (#737)

## 0.10.0 (June 2014)

This release contains a major rewrite of the tree-based sync and caching
system. Old cached data will be converted to the new format automatically.

### Breaking changes

* `getAll` and `getListing` now return an empty object instead of undefined when no items
    match the query
* Object meta data has been removed from the `getListing` response, until we have a better
    implementation (#652, #720, #721)
* `disconnect` event removed in favor of `disconnected`
* `remoteStorage.claimAccess` removed in favor of `remoteStorage.access.claim`
* `BaseClient#use` and `BaseClient#release` removed in favor of `BaseClient#cache`
* Change events with origin 'window' are now disabled by default
* The config variable `RemoteStorage._log` was renamed to `RemoteStorage.config.logging`

### New features

* Major rewrite of the tree-based sync and caching system
* Performance was improved, especially when storing many small objects
* A new `maxAge` parameter is available in the various BaseClient get...
    functions, where you can specify the maximum age of cached results (in ms).
    This replaces the ready-queue from 0.9.0.
* Caching of subtrees can now be configured as 'ALL', 'SEEN', or 'FLUSH'. The second
    one means documents that were seen once, will stay synced. Check the
    [caching documentation](http://remotestorage.io/doc/code/files/caching-js.html)
    for details. `caching.enable(path)` will use 'ALL' by default.
* Add and use background sync interval, based on Page Visibility API (#462)
* Choose from which origins change events are emitted via `RemoteStorage.config.changeEvents`
* More unit tests
* A 'local-events-done' event is emitted by `remoteStorage.local` after all events with origin 'local' have been emitted on page load.

### Experimental features

* Google Drive is now supported as an experimental backend
* Dropbox is now supported as an experimental backend
* Support for browser implied authentication
* With `remoteStorage.displayWidget({encryption: true})`, the user will be invited to enter a secret (password) into the widget, which the app can then use for client-side encryption.

### Bugfixes

* Anonymous mode is fixed and working as expected again
* Fix private browsing mode in Firefox
* Handle 404s for directory GETs (#573)
* Always quote If-None-Match headers (#584)
* Widget only pulses when syncing changes (#437)
* Fire `connected` event on startup if remote already connected
* Fix error on remoteStorage.local.reset (#630)
* Support non-ascii filenames in the Dropbox backend (#628)
* When no widget is present, log undisplayed errors (#639)
* Restore the document fragment (hash URL) after the OAuth dance (#646)
* Fix handling of custom JSON-LD contexts for types (#661)
* Widget bubble closing spontaneously (#683)
* Fix incorrect handling of 404 responses (#718)
* Add content-types to remote change events (#655)
* Fix caching of binary data (#670)
* The widget placeholder text was restored to 'user@provider.com' (#731)

## 0.9.0 (December 2013)

This release consists of awesome contributions from @skddc, @galfert, @ggrin,
@michielbdejong, @clochix, @silverbucket, @gregkare, and @rakyll - you can participate
in the next release via https://github.com/remotestorage/remotestorage.js/issues!

* Rename the 'root' module to '*' (breaking change)
* Return a map instead of a string per item in getListing (breaking change)
* Support for draft-dejong-remotestorage-02.txt
* Fix multiple overlapping requests on first pageload
* Fix requests going to non-ready cache before initial sync finished
* Better error messages in widget
* Label change events from initial sync as 'local' if they come from local
* Add JSHint config
* Add in-memory storage for when neither IndexedDB nor localStorage are
    available
* Move the example server and example apps to gh:remotestorage/starter-kit
* Add setSyncInterval method
* Add i18n module, enable translation/customization of all content strings
* Fix minor issues in the experimental GoogleDrive backend (in dark launch)

## 0.8.3 (November 2013)

* Make sure to clear auth token after disconnect
* Fix invalid conditional request headers (If-Match & If-None-Match)
* Fix double-encoded paths
* Removed broken example app

## 0.8.2 (October 2013)

* Size reduced by almost 25%, to 34K minified, gzipped
* Fixes issues with non-ASCII characters in item names
* Fixes unnecessary polling of documents whose entry in the parent directory
    did not change
* Widget fixes
* Compatible with [remotestorage-02](https://github.com/remotestorage/spec/blob/master/draft-dejong-remotestorage-head.txt)
    (although nothing needed to change for this)

## 0.8.1 (August 2013)

* Update the example server
* Fix edge case in sync with incoming deletions of entire directories

## 0.8.0 (August 2013)

### Overview:

* Rewritten: RemoteStorage, WireClient, BaseClient, Sync, IndexedDB
* Supports the three latest spec versions:
  - 2012.04 (http://www.w3.org/community/unhosted/wiki/RemoteStorage-2012.04)
  - remotestorage-00 (https://tools.ietf.org/html/draft-dejong-remotestorage-00)
  - remotestorage-01 (https://tools.ietf.org/html/draft-dejong-remotestorage-01)
* The default cache backend changed to indexedDB
* Modularized build (build/components.json lists groups and their dependencies)
* Removed internal use of AMD. Everything is nested below the global RemoteStorage namespace now.
* Added 'inspect' debug widget. If debug support is built in, use remoteStorage.inspect() in your app to try it.

### Changes to the API:

* Global 'remoteStorage' object is now an instance of RemoteStorage
* Caching & Access settings are persisted and survive a redirect
* remoteStorage.claimAccess no longer returns a promise (was deprecated in 0.7.1)
* BaseClient#use/BaseClient#release are deprecated in favor of BaseClient#cache
* Added BaseClient#scope() to get BaseClient instances of paths nested below the module root.
* Made validation schemas global (schemas from other modules can be referred to using: <module-name>/<type-alias>)
* Added 'inspect' debug widget. If debug support is built in, use remoteStorage.inspect() in your app to try it.
* Deprectated the "util" part. It contained a lot of utility functions that bloated the library and are also
    available in the same or similar form from third-party libraries.
    Until the next major release a subset of the "util" object will still be available (see "src/legacy.js" for
    a list of methods that are included).

## 0.7.0 (January 2013)

* Big breaking change!
* Introduces modules, and changes everything completely.
* Nothing is the same as in version 0.6

## 0.6.9

* Make sure token is decoded before passing it as Authorization header
* don't log confusing JSON parse error, if hasn't been stored yet
* Update new webfinger format
* Add read-write-web-00#webdav support
* Add read-write-web-00#simple support

## 0.6.8

* Surfnet hardcoded list update
* Add remoteStorage.createStorageInfo
* Set client_id correctly

## 0.6.7

* Add fontys.nl to hardcoded
* Fix getCollection

## 0.6.6

* Fix wrong error message when user address doesn't parse
* Fix wrong requirement for global 'location' variable in nodejs

## 0.6.5

* Fix tests
* Include surfnet pilot
* Clean up storageInfo format

## 0.6.4

* Fix JRD syntax

## 0.6.3

* No trailing slash after empty base path

## 0.6.2

* Fix legacy detection for OAuth scopes format
* On legacy storage, change all slashes to underscores except for the one between category and item
* Deal with non-string user addresses in getStorageInfo
* Allow hyphens and underscores in user part of user addresses
* Revert all user addresses to lower case
* Correct new rel to https://www.w3.org/community/rww/wiki/simple-00

## 0.6.1

* Fix the tests again
* Add ':rw' or ':r' to OAuth scopes
* DON'T USE: the legacy format detection is broken in this revision

## 0.6.0

* Losen the requirement that the basePath you OAuth to should be a category, so now instead of 'category/key' we use 'basePath/relPath'
* DON'T USE: I later found out that the tests were not being run in this revision, so there are some bugs in it.

## 0.5.6

* Fix missing error handler in ajaxNode(). only affects remoteStorage-node.js

## 0.5.5

* Fix input typeof() checks. no big impact

## 0.5.4

* Fix a problem in xrd parsing. upgrading highly recommended

## 0.5.3

* Added guessStorageInfo fallback
* Added temporary migration code for 160 users who are still on deprecated fakefinger
* Works in combination with http://proxy.unhosted.org/checkIrisCouch
* Added nodejs support
* Added (non-functional) straw man code for IE
* Pushing this version only for temp use in Libre Docs, don't use this at home until we test the new stuff some more

## 0.5.2

* Restructured code to make room for multi-platform

## 0.5.1

* Got rid of fakefinger again, and made webfinger code nicer
* To build, run 'cd build; node build.js'

## 0.5.0

* BREAKING CHANGE in how you include the library: got rid of require.
* To build, run 'sh build.sh'

## 0.4.7

* Added r.js build script

## 0.4.6

* Moved tests to sinonjs, fixed some significant bugs in couch 409 handling
* Added builds/ and downloads/ directories
* Now returning (null, undefined) instead of (404, '') when an item is not found

## 0.4.5

* Switched from useraddress.net/fakefinger to proxy.unhosted.org/lookup
* Fixed CouchDB _rev in DELETE https://github.com/unhosted/remoteStorage.js/issues/39
* Removed dead code relating to single-origin webfinger

## 0.4.4

* Added unit tests

## 0.4.3

* Made requires relative

## 0.4.2

* First public version of this library implementing http://unhosted.org/#developer

[1]: https://github.com/remotestorage/remotestorage.js/releases
